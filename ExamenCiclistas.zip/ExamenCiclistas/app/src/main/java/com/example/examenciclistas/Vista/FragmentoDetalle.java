package com.example.examenciclistas.Vista;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.examenciclistas.Interfaz.IListenerCiclistas;
import com.example.examenciclistas.Modelo.Cyclist;
import com.example.examenciclistas.R;

import org.w3c.dom.Text;

import java.util.List;

public class FragmentoDetalle extends Fragment {

    //VAMOS A RELLENAR CICLISTAS PARA LA LISTA
    private Cyclist ciclista;

    private TextView tvNombre;
    private TextView tvApellido;
    private TextView tvGrupo;

    public interface IOnAttachListener{
        Cyclist getCiclista();
    }

    public FragmentoDetalle() {
        super(R.layout.fragmento_detalle);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvNombre.setText(view.findViewById(R.id.tvNombre));
        tvApellido.setText(view.findViewById(R.id.tvApellido));
        tvGrupo.setText(view.findViewById(R.id.tvGrupo));
        if (ciclista != null) {
            cargarDatos(ciclista);
        }

    }

    public void cargarDatos(Cyclist ciclista ){
        tvNombre.setText(ciclista.getName());
        tvApellido.setText(ciclista.getSurname());
        tvGrupo.setText(ciclista.getTeam());
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        IOnAttachListener iOnAttachListener = (IOnAttachListener) context;
        ciclista = iOnAttachListener.getCiclista();
    }



}
