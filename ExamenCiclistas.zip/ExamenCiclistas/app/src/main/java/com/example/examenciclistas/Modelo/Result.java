package com.example.examenciclistas.Modelo;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Result implements Serializable {
    private final int cyclistId;
    private final int hours;
    private final int minutes;
    private final int seconds;

    //Un ciclista tiene su tiempo
    public Result(int cyclistId, int hours, int minutes, int seconds) {
        this.cyclistId = cyclistId;
        this.hours = hours;
        this.minutes = minutes;
        this.seconds = seconds;
    }

    public int getCyclistId() {
        return cyclistId;
    }

    public int getHours() {
        return hours;
    }

    public int getMinutes() {
        return minutes;
    }

    public int getSeconds() {
        return seconds;
    }

    @NonNull
    @Override
    public String toString() {
        return "Result{" +
                "cyclistId=" + cyclistId +
                ", hour=" + hours +
                ", minutes=" + minutes +
                ", seconds=" + seconds +
                '}';
    }
}
