package com.example.examenciclistas.Vista;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.examenciclistas.Interfaz.IListenerCiclistas;
import com.example.examenciclistas.Modelo.Cyclist;
import com.example.examenciclistas.R;

import java.util.List;

public class Adaptador extends RecyclerView.Adapter<Adaptador.HolderAdaptador> {

    private final Context context;
    private Cyclist ciclista;
    private final List<Cyclist> ciclistas;
    private final IListenerCiclistas iListenerCiclistas;

    public Adaptador(Context context, List<Cyclist> ciclistas, IListenerCiclistas iListenerCiclistas) {
        this.context = context;
        this.ciclistas = ciclistas;
        this.iListenerCiclistas = iListenerCiclistas;
    }

    @NonNull
    @Override
    public HolderAdaptador onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_item,parent,false);
        return new HolderAdaptador(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderAdaptador holder, int position) {
        ciclista = ciclistas.get(position);
        if (ciclista==null){
            throw new NullPointerException();
        }
        holder.cargarDatos(ciclista);

    }

    @Override
    public int getItemCount() {
        return ciclistas.size();
    }

    public class HolderAdaptador extends RecyclerView.ViewHolder implements View.OnClickListener{

        private TextView tvId;
        private ImageView ivFoto;
        private TextView tvNombre;
        private TextView tvApellido;
        private TextView tvGrupo;


        public HolderAdaptador(@NonNull View itemView) {
            super(itemView);
            tvId = itemView.findViewById(R.id.tvId);
            ivFoto = itemView.findViewById(R.id.ivFoto);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvApellido = itemView.findViewById(R.id.tvApellido);
            tvGrupo = itemView.findViewById(R.id.tvGrupo);
            itemView.setOnClickListener(this);
        }

        public void cargarDatos(Cyclist ciclista){
            String nombre = "ciclyst_"+ciclista.getCyclistId();
            int id = context.getResources().getIdentifier(nombre,"drawable",context.getPackageName());
            tvId.setText(String.valueOf(ciclista.getCyclistId()));
            ivFoto.setImageResource(id);
            tvNombre.setText(ciclista.getName());
            tvApellido.setText(ciclista.getSurname());
            tvGrupo.setText(ciclista.getTeam());
        }


        @Override
        public void onClick(View view) {
            if (view != null){
                iListenerCiclistas.onCiclistaSeleccionado(getBindingAdapterPosition());
            }
        }
    }
}
