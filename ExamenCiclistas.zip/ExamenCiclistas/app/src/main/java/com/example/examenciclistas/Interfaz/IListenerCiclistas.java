package com.example.examenciclistas.Interfaz;

public interface IListenerCiclistas {
    void onCiclistaSeleccionado(int posicion) ;
}
