package com.germangascon.retrofitsample.interfaces;

public interface IListenerList {
    void onItemSelected(int position);
}
